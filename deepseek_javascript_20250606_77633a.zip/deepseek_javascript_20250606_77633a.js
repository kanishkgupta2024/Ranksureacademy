const express = require('express');
const {
  getClasses,
  getClass,
  createClass,
  updateClass,
  deleteClass,
  scheduleSession,
  rescheduleSession,
  enrollStudent
} = require('../controllers/classController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router
  .route('/')
  .get(protect, getClasses)
  .post(protect, authorize('admin', 'teacher'), createClass);

router
  .route('/:id')
  .get(protect, getClass)
  .put(protect, authorize('admin', 'teacher'), updateClass)
  .delete(protect, authorize('admin', 'teacher'), deleteClass);

router
  .route('/:id/schedule')
  .post(protect, authorize('admin', 'teacher'), scheduleSession);

router
  .route('/:id/schedule/:sessionId')
  .put(protect, authorize('admin', 'teacher'), rescheduleSession);

router
  .route('/:id/enroll')
  .post(protect, authorize('admin', 'student'), enrollStudent);

module.exports = router;