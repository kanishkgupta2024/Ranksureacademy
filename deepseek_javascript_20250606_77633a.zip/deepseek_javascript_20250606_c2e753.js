const Quiz = require('../models/Quiz');
const Class = require('../models/Class');
const asyncHandler = require('../middleware/async');

// @desc    Get all quizzes for a class
// @route   GET /api/classes/:classId/quizzes
// @access  Private
exports.getQuizzes = asyncHandler(async (req, res, next) => {
  // Check if user is enrolled in the class or is the teacher
  const classObj = await Class.findById(req.params.classId);
  
  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.classId}`, 404));
  }

  if (!classObj.teacher.equals(req.user.id) && !classObj.students.includes(req.user.id)) {
    return next(
      new ErrorResponse(`User not authorized to access quizzes for this class`, 401)
    );
  }

  const quizzes = await Quiz.find({ class: req.params.classId });

  res.status(200).json({
    success: true,
    count: quizzes.length,
    data: quizzes
  });
});

// @desc    Get single quiz
// @route   GET /api/quizzes/:id
// @access  Private
exports.getQuiz = asyncHandler(async (req, res, next) => {
  const quiz = await Quiz.findById(req.params.id).populate('class', 'title teacher');

  if (!quiz) {
    return next(new ErrorResponse(`Quiz not found with id of ${req.params.id}`, 404));
  }

  // Check if user is teacher or enrolled student
  const classObj = await Class.findById(quiz.class);
  
  if (!classObj.teacher.equals(req.user.id) && !classObj.students.includes(req.user.id)) {
    return next(
      new ErrorResponse(`User not authorized to access this quiz`, 401)
    );
  }

  res.status(200).json({
    success: true,
    data: quiz
  });
});

// @desc    Create quiz
// @route   POST /api/classes/:classId/quizzes
// @access  Private (Teacher/Admin)
exports.createQuiz = asyncHandler(async (req, res, next) => {
  req.body.class = req.params.classId;
  req.body.createdBy = req.user.id;

  const classObj = await Class.findById(req.params.classId);
  
  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.classId}`, 404));
  }

  // Make sure user is class teacher or admin
  if (!classObj.teacher.equals(req.user.id) && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to create quizzes for this class`, 401)
    );
  }

  const quiz = await Quiz.create(req.body);

  res.status(201).json({
    success: true,
    data: quiz
  });
});

// @desc    Update quiz
// @route   PUT /api/quizzes/:id
// @access  Private (Teacher/Admin)
exports.updateQuiz = asyncHandler(async (req, res, next) => {
  let quiz = await Quiz.findById(req.params.id);

  if (!quiz) {
    return next(new ErrorResponse(`Quiz not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is quiz creator or admin
  if (quiz.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to update this quiz`, 401)
    );
  }

  quiz = await Quiz.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: quiz
  });
});

// @desc    Delete quiz
// @route   DELETE /api/quizzes/:id
// @access  Private (Teacher/Admin)
exports.deleteQuiz = asyncHandler(async (req, res, next) => {
  const quiz = await Quiz.findById(req.params.id);

  if (!quiz) {
    return next(new ErrorResponse(`Quiz not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is quiz creator or admin
  if (quiz.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to delete this quiz`, 401)
    );
  }

  await quiz.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Submit quiz answers
// @route   POST /api/quizzes/:id/submit
// @access  Private (Student)
exports.submitQuiz = asyncHandler(async (req, res, next) => {
  const quiz = await Quiz.findById(req.params.id);

  if (!quiz) {
    return next(new ErrorResponse(`Quiz not found with id of ${req.params.id}`, 404));
  }

  // Check if user is enrolled in the class
  const classObj = await Class.findById(quiz.class);
  
  if (!classObj.students.includes(req.user.id)) {
    return next(
      new ErrorResponse(`User not authorized to submit this quiz`, 401)
    );
  }

  // Calculate score
  const { answers } = req.body;
  let score = 0;

  quiz.questions.forEach((question, index) => {
    const selectedOption = answers[index];
    if (question.options[selectedOption].isCorrect) {
      score += question.points;
    }
  });

  // Save submission (you would create a Submission model for this)
  // const submission = await Submission.create({
  //   quiz: quiz._id,
  //   student: req.user.id,
  //   answers,
  //   score
  // });

  res.status(200).json({
    success: true,
    data: {
      score,
      total: quiz.questions.reduce((sum, question) => sum + question.points, 0)
    }
  });
});