const express = require('express');
const {
  getQuizzes,
  getQuiz,
  createQuiz,
  updateQuiz,
  deleteQuiz,
  submitQuiz
} = require('../controllers/quizController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

router
  .route('/')
  .get(protect, getQuizzes)
  .post(protect, authorize('admin', 'teacher'), createQuiz);

router
  .route('/:id')
  .get(protect, getQuiz)
  .put(protect, authorize('admin', 'teacher'), updateQuiz)
  .delete(protect, authorize('admin', 'teacher'), deleteQuiz);

router
  .route('/:id/submit')
  .post(protect, authorize('student'), submitQuiz);

module.exports = router;