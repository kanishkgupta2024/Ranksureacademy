import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { getQuiz, submitQuiz } from '../../services/quizService';
import Timer from '../ui/Timer';

const QuizPage = () => {
  const { quizId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(state => state.auth);
  const { quiz, isLoading, isError, message } = useSelector(state => state.quizzes);
  
  const [answers, setAnswers] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(null);
  const [timeLeft, setTimeLeft] = useState(null);

  useEffect(() => {
    dispatch(getQuiz(quizId));
  }, [quizId, dispatch]);

  useEffect(() => {
    if (quiz?.timeLimit) {
      setTimeLeft(quiz.timeLimit * 60); // Convert minutes to seconds
    }
  }, [quiz]);

  useEffect(() => {
    if (timeLeft === 0) {
      handleSubmit();
    }
  }, [timeLeft]);

  const handleAnswerSelect = (questionIndex, optionIndex) => {
    const newAnswers = [...answers];
    newAnswers[questionIndex] = optionIndex;
    setAnswers(newAnswers);
  };

  const handleSubmit = async () => {
    try {
      const result = await dispatch(submitQuiz({
        quizId,
        answers
      })).unwrap();
      setScore(result.score);
      setSubmitted(true);
    } catch (err) {
      console.error(err);
    }
  };

  if (isLoading) return <div>Loading...</div>;
  if (isError) return <div>{message}</div>;

  return (
    <div className="container mx-auto px-4 py-8">
      {!submitted ? (
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">{quiz?.title}</h2>
            {quiz?.timeLimit && (
              <Timer 
                initialTime={timeLeft} 
                onTick={setTimeLeft} 
                className="text-lg font-semibold"
              />
            )}
          </div>
          
          <div className="space-y-8">
            {quiz?.questions?.map((question, qIndex) => (
              <div key={qIndex} className="border-b pb-6">