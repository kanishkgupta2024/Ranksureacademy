const Class = require('../models/Class');
const User = require('../models/User');
const asyncHandler = require('../middleware/async');

// @desc    Get all classes
// @route   GET /api/classes
// @access  Private
exports.getClasses = asyncHandler(async (req, res, next) => {
  let query;
  
  if (req.user.role === 'teacher') {
    query = Class.find({ teacher: req.user.id });
  } else if (req.user.role === 'student') {
    query = Class.find({ students: req.user.id });
  } else {
    query = Class.find();
  }

  const classes = await query.populate('teacher', 'name email').populate('students', 'name email');

  res.status(200).json({
    success: true,
    count: classes.length,
    data: classes
  });
});

// @desc    Get single class
// @route   GET /api/classes/:id
// @access  Private
exports.getClass = asyncHandler(async (req, res, next) => {
  const classObj = await Class.findById(req.params.id)
    .populate('teacher', 'name email')
    .populate('students', 'name email');

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: classObj
  });
});

// @desc    Create class
// @route   POST /api/classes
// @access  Private (Admin/Teacher)
exports.createClass = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.teacher = req.user.id;

  const classObj = await Class.create(req.body);

  res.status(201).json({
    success: true,
    data: classObj
  });
});

// @desc    Update class
// @route   PUT /api/classes/:id
// @access  Private (Admin/Teacher)
exports.updateClass = asyncHandler(async (req, res, next) => {
  let classObj = await Class.findById(req.params.id);

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is class owner or admin
  if (classObj.teacher.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to update this class`, 401)
    );
  }

  classObj = await Class.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: classObj
  });
});

// @desc    Delete class
// @route   DELETE /api/classes/:id
// @access  Private (Admin/Teacher)
exports.deleteClass = asyncHandler(async (req, res, next) => {
  const classObj = await Class.findById(req.params.id);

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is class owner or admin
  if (classObj.teacher.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to delete this class`, 401)
    );
  }

  await classObj.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Schedule class session
// @route   POST /api/classes/:id/schedule
// @access  Private (Admin/Teacher)
exports.scheduleSession = asyncHandler(async (req, res, next) => {
  const classObj = await Class.findById(req.params.id);

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is class owner or admin
  if (classObj.teacher.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to schedule sessions for this class`, 401)
    );
  }

  classObj.schedule.push(req.body);
  await classObj.save();

  res.status(200).json({
    success: true,
    data: classObj.schedule
  });
});

// @desc    Reschedule class session
// @route   PUT /api/classes/:id/schedule/:sessionId
// @access  Private (Admin/Teacher)
exports.rescheduleSession = asyncHandler(async (req, res, next) => {
  const classObj = await Class.findById(req.params.id);

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is class owner or admin
  if (classObj.teacher.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to reschedule sessions for this class`, 401)
    );
  }

  const sessionIndex = classObj.schedule.findIndex(
    session => session._id.toString() === req.params.sessionId
  );

  if (sessionIndex === -1) {
    return next(new ErrorResponse(`Session not found with id of ${req.params.sessionId}`, 404));
  }

  classObj.schedule[sessionIndex] = {
    ...classObj.schedule[sessionIndex].toObject(),
    ...req.body
  };

  await classObj.save();

  res.status(200).json({
    success: true,
    data: classObj.schedule[sessionIndex]
  });
});

// @desc    Enroll student in class
// @route   POST /api/classes/:id/enroll
// @access  Private (Admin/Student)
exports.enrollStudent = asyncHandler(async (req, res, next) => {
  const classObj = await Class.findById(req.params.id);

  if (!classObj) {
    return next(new ErrorResponse(`Class not found with id of ${req.params.id}`, 404));
  }

  // Check if already enrolled
  if (classObj.students.includes(req.user.id)) {
    return next(new ErrorResponse(`Student is already enrolled in this class`, 400));
  }

  classObj.students.push(req.user.id);
  await classObj.save();

  // Add class to user's enrolledClasses
  await User.findByIdAndUpdate(req.user.id, {
    $push: { enrolledClasses: classObj._id }
  });

  res.status(200).json({
    success: true,
    data: classObj
  });
});