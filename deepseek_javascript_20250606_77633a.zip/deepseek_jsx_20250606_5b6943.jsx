import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { scheduleSession, rescheduleSession } from '../../services/classService';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import Modal from '../ui/Modal';

const ClassScheduler = () => {
  const { classId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(state => state.auth);
  const { class: classData } = useSelector(state => state.classes);
  
  const [date, setDate] = useState(new Date());
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [meetingLink, setMeetingLink] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedSession, setSelectedSession] = useState(null);

  useEffect(() => {
    // Fetch class data if not already loaded
  }, [classId, dispatch]);

  const handleScheduleSession = async (e) => {
    e.preventDefault();
    try {
      await dispatch(scheduleSession({
        classId,
        date,
        startTime,
        endTime,
        meetingLink
      })).unwrap();
      // Reset form
      setStartTime('');
      setEndTime('');
      setMeetingLink('');
    } catch (err) {
      console.error(err);
    }
  };

  const handleReschedule = async (e) => {
    e.preventDefault();
    try {
      await dispatch(rescheduleSession({
        classId,
        sessionId: selectedSession._id,
        date,
        startTime: startTime || selectedSession.startTime,
        endTime: endTime || selectedSession.endTime,
        meetingLink: meetingLink || selectedSession.meetingLink
      })).unwrap();
      setShowModal(false);
      setSelectedSession(null);
    } catch (err) {
      console.error(err);
    }
  };

  const openRescheduleModal = (session) => {
    setSelectedSession(session);
    setDate(new Date(session.date));
    setStartTime(session.startTime);
    setEndTime(session.endTime);
    setMeetingLink(session.meetingLink);
    setShowModal(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-6">Class Schedule</h2>
      
      {user?.role === 'teacher' || user?.role === 'admin' ? (
        <div className="mb-8 bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold mb-4">Schedule New Session</h3>
          <form onSubmit={handleScheduleSession}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <Calendar 
                  onChange={setDate} 
                  value={date} 
                  className="border rounded p-2 w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="border rounded p-2 w-full"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="border rounded p-2 w-full"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Meeting Link</label>
                <input
                  type="url"
                  value={meetingLink}
                  onChange={(e) => setMeetingLink(e.target.value)}
                  className="border rounded p-2 w-full"
                  placeholder="https://zoom.us/j/123456789"
                  required
                />
              </div>
            </div>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Schedule Session
            </button>
          </form>
        </div>
      ) : null}

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Upcoming Sessions</h3>
        {classData?.schedule?.length > 0 ? (
          <div className="space-y-4">
            {classData.schedule
              .filter(session => session.status === 'scheduled')
              .sort((a, b) => new Date(a.date) - new Date(b.date))
              .map(session => (
                <div key={session._id} className="border p-4 rounded flex justify-between items-center">
                  <div>
                    <p className="font-medium">
                      {new Date(session.date).toLocaleDateString()} • {session.startTime} - {session.endTime}
                    </p>
                    {session.meetingLink && (
                      <a 
                        href={session.meetingLink} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        Join Meeting
                      </a>
                    )}
                  </div>
                  {(user?.role === 'teacher' || user?.role === 'admin') && (
                    <button
                      onClick={() => openRescheduleModal(session)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      Reschedule
                    </button>
                  )}
                </div>
              ))}
          </div>
        ) : (
          <p>No scheduled sessions found.</p>
        )}
      </div>

      {/* Reschedule Modal */}
      <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
        <h3 className="text-xl font-semibold mb-4">Reschedule Session</h3>
        <form onSubmit={handleReschedule}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <Calendar 
                onChange={setDate} 
                value={date} 
                className="border rounded p-2 w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="border rounded p-2 w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="border rounded p-2 w-full"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Meeting Link</label>
              <input
                type="url"
                value={meetingLink}
                onChange={(e) => setMeetingLink(e.target.value)}
                className="border rounded p-2 w-full"
                placeholder="https://zoom.us/j/123456789"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Update Session
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ClassScheduler;