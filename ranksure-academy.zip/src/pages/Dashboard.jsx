import React from 'react';
function Dashboard() {
  return <div>Dashboard Page</div>;
}
export default Dashboard;